import React, { useEffect, useState } from 'react';
import axios from 'axios'; 
import { Pie } from 'react-chartjs-2'; 
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels'; 
import './StartupHome.css';

ChartJS.register(ArcElement, Tooltip, Legend, ChartDataLabels);

const StartupHome = () => {
  const [startupInfo, setStartupInfo] = useState({
    location: '',
    domain: '',
  });

  const [editableFields, setEditableFields] = useState({
    location: false,
    domain: false,
  });

  const [prediction, setPrediction] = useState(null);
  const [chartData, setChartData] = useState(null);
  const [isButtonClicked, setIsButtonClicked] = useState(false);

  useEffect(() => {
    const storedStartups = JSON.parse(localStorage.getItem('startups')) || [];
    if (storedStartups.length > 0) {
      const latestStartup = storedStartups[storedStartups.length - 1];
      setStartupInfo({
        location: latestStartup.location,
        domain: latestStartup.domain,
      });
    }
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setStartupInfo({
      ...startupInfo,
      [name]: value,
    });
  };

  const toggleEditable = (field) => {
    setEditableFields((prevState) => ({
      ...prevState,
      [field]: !prevState[field],
    }));
  };

  const handleCheck = async () => {
    setIsButtonClicked(true);
    try {
      const response = await axios.post('http://localhost:5000/predict', {
        'Area Name': startupInfo.location,
        'Business Name': startupInfo.domain,
      });

      const successRate = response.data["Predicted Success Rate"];
      setPrediction(successRate);

      const failureRate = 100 - successRate;

      setChartData({
        labels: ['Success', 'Failure'],
        datasets: [
          {
            data: [successRate, failureRate],
            backgroundColor: ['#2ecc71', '#e74c3c'],  // Success: Green, Failure: Red
            hoverBackgroundColor: ['#27ae60', '#c0392b'],  // Darker shades on hover
            borderWidth: 2,
          },
        ],
      });
    } catch (error) {
      console.error('Error fetching prediction:', error);
      alert('Error fetching prediction. Please try again.');
    }
  };

  return (
    <div className="startup-home-container">
      <h2>Startup Information</h2>
      <div className="startup-info">
        <div className="info-field">
          <label>Location:</label>
          {editableFields.location ? (
            <input
              type="text"
              name="location"
              value={startupInfo.location}
              onChange={handleInputChange}
              required
            />
          ) : (
            <span>{startupInfo.location}</span>
          )}
          <button onClick={() => toggleEditable('location')}>
            {editableFields.location ? 'Save' : 'Edit'}
          </button>
        </div>
        <div className="info-field">
          <label>Domain:</label>
          {editableFields.domain ? (
            <input
              type="text"
              name="domain"
              value={startupInfo.domain}
              onChange={handleInputChange}
              required
            />
          ) : (
            <span>{startupInfo.domain}</span>
          )}
          <button onClick={() => toggleEditable('domain')}>
            {editableFields.domain ? 'Save' : 'Edit'}
          </button>
        </div>
      </div>

      <div className="check-button-container">
        <button
          onClick={handleCheck}
          className="check-button"
          disabled={isButtonClicked}
        >
          {isButtonClicked ? 'Processing...' : 'Check Information'}
        </button>
      </div>

      {prediction !== null && (
        <div className="prediction-result">
          <h3>Predicted Success Rate: {prediction}%</h3>
        </div>
      )}

      {chartData && (
        <div className="chart-container">
          <Pie
            data={chartData}
            options={{
              responsive: true,
              plugins: {
                legend: {
                  display: true,
                  position: 'bottom',
                  labels: {
                    font: {
                      size: 14,
                      weight: 'bold',
                    },
                    padding: 15,
                  },
                },
                datalabels: {
                  color: 'black', // White color for the data labels
                  font: {
                    size: 16,
                    weight: 'bold',
                  },
                  formatter: (value) => `${value}%`, // Display percentage values
                },
              },
              maintainAspectRatio: false,
            }}
            width={400}
            height={400}
          />
        </div>
      )}
    </div>
  );
};

export default StartupHome;
